function [output,T] = GeneratA_Dirch(h,hx,hy) 
    [x,y]  =   meshgrid(0:h:hx,hy:-h:0);
%     u      =   myfunc(x,y);
%     u1     =   u(2:end-1,2:end-1);
%     us     =   u1(:); 
    n      =   hx/h-1;
    e      =   ones(n,1);
    T      =   spdiags([-e 2*e -e], -1:1 ,n,n);
    A      =   kron(speye(n),T)+kron(T,speye(n));
    output =   A;
end