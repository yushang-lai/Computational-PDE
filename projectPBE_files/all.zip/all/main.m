% Multigrid
L  = 3;
h  = 1/2^L;
hx = 1;
ii = 50000;
w  = 0.5;
% Step 1 Weighted Jacobi & Gasuss-Seidel Smoother 

% Weighter Jacobi 

u     = zeros(hx/h+1,hx/h+1);
u_w_j = Smoother_Weighted_Jaco(h,hx,u,ii,w);
u_g_s = Smoother_Gauss_Seidel1(h,hx,u,ii); 

ii1   = 10;
ii2   = 11;
ii3   = 12;
ii4   = 13;

u_g_s_1 = Smoother_Gauss_Seidel1(h,hx,u,ii1); 
u_g_s_2 = Smoother_Gauss_Seidel1(h,hx,u,ii2); 
u_g_s_3 = Smoother_Gauss_Seidel1(h,hx,u,ii3); 
u_g_s_4 = Smoother_Gauss_Seidel1(h,hx,u,ii4); 

k1_k  = max(max((u_g_s_4-u_g_s_3)));
k_k1  = max(max((u_g_s_3-u_g_s_2)));
k1_k2 = max(max((u_g_s_2-u_g_s_1)));
disp('The convergence rate is:');
q     = log(abs(k1_k/k_k1))/log(abs(k_k1/k1_k2))


% Plot the error for h = 1/16
figure(1);
L  = 4;
h  = 1/2^L;
u     = zeros(hx/h+1,hx/h+1);
err_lst =  Smoother_Gauss_Seidel_alpha(h,hx,u,ii);
subplot(2,2,1);
plot([3:3:42],err_lst)
title('h=1/16 error plot')


% Get Step number for h=1/4
L  = 2;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
disp('The step required to get h^2 error h = 1/4 is:');
nstep1 =  Smoother_Gauss_Seidel_belta(h,hx,u,ii)


% Get Step number for h = 1/128
L  = 7;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
disp('The step required to get h^2 error h = 1/128 is:');
nstep2 =  Smoother_Gauss_Seidel_belta(h,hx,u,ii)

L  = 1;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
nstep3 =  Smoother_Gauss_Seidel_belta(h,hx,u,ii);

L  = 6;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
nstep4 =  Smoother_Gauss_Seidel_belta(h,hx,u,ii);

subplot(2,2,2);
plot([1 2 6 7],[nstep3 nstep1 nstep4 nstep2],"o");
xlabel('L')
ylabel('*# steps')
title('# of steps r.p.t L ')

% Choose a random initial guess and plot the error in the first three steps
L  = 4;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
[err_lst, rando] =  Smoother_Gauss_Seidel_gamma(h,hx,u,ii);
subplot(2,2,3);
plot([1 2 3],err_lst);
title('random start')

% Step 2 Two-Grid Method

figure(2);
subplot(2,1,1);
L  = 2;
h  = 1/2^L;
hx = 1;
u  = zeros(hx/h+1,hx/h+1);
u_g_s_1 = Smoother_Gauss_Seidel1(h,hx,u,10000);
J = 2;
mu = 10;
f  = h^2*ones((hx/h+1));
err_lst1 = [];
for i =1:10
    u = two_grid(u,f,J,mu);
    err_lst1 = [err_lst1 abs(max(max(u(2:end-1,2:end-1)-u_g_s_1)))];
end
plot(err_lst1);
title('h=1/4');

subplot(2,1,2);
L  = 7;
h  = 1/2^L;
hx = 1;
u  = zeros(hx/h+1,hx/h+1);
u_g_s_2 = Smoother_Gauss_Seidel1(h,hx,u,10000);
J = 2;
mu = 10;
f  = h^2*ones((hx/h+1));
err_lst2 = [];
for i =1:10
    u = two_grid(u,f,J,mu);
    err_lst2 = [err_lst2 abs(max(max(u(2:end-1,2:end-1)-u_g_s_2)))];
end

plot(err_lst2);
title('h=1/128');

% Step 3 Vcycle
figure(3)
L  = 7;
h  = 1/2^L;
mu = 10;
hx = 1;
u2  = zeros(hx/h+1,hx/h+1);
error =1;
tol = 0.1*h^2;
J = 4;
f  = h^2*ones((hx/h+1));
u_g_s_2 = Smoother_Gauss_Seidel1(h,hx,u2,10000);
kk =1;
error_lst = [];
while error > tol
    u2 = Vcycle1(u2,J);
    kk = kk+1;
    error = abs(max(max(u2(2:end-1,2:end-1)-u_g_s_2)));
    error_lst = [error_lst error];
end
plot(error_lst);
title("V cycle")




% Multigrid on Hierarchical Grids
% Step 1
[node,elem] = circlemesh(0,0,1,0.25);
J = 4;
HB_cell       = cell(J,1);
bdNode_cell   = cell(J,1);
freeNode_cell = cell(J,1);

for i = 1:J
    [node,elem,~,HB] = uniformrefine(node,elem);
    HB_cell{i}       = double(HB);
    [bdNode,bdEdge,isBdNode,isBdElem]       = findboundary(elem);
    freeNode                                = find(~isBdNode);
    bdNode_cell{i}                          = bdNode;
    freeNode_cell{i}                        = freeNode;
end
%[node,elem,~,HB] = uniformrefine(node,elem);
%[elem,HB,~] = uniformcoarsenred(elem);
figure(4);
% Step 2
% showmesh(node,elem);
N                                       =  length(node);
mid1                                    = (node(elem(:,2),:)+node(elem(:,3),:))/2;
mid2                                    = (node(elem(:,3),:)+node(elem(:,1),:))/2;
mid3                                    = (node(elem(:,1),:)+node(elem(:,2),:))/2;
area0                                   = assembling_area(node,elem);
bt1                                     = area0.*(f1(mid2)+f1(mid3))/6;
bt2                                     = area0.*(f1(mid3)+f1(mid1))/6;
bt3                                     = area0.*(f1(mid1)+f1(mid2))/6;
b                                       = accumarray(elem(:),[bt1;bt2;bt3],[N 1]);

[bdNode,bdEdge,isBdNode,isBdElem]       = findboundary(elem);
freeNode                                = find(~isBdNode);
u                                       = zeros(N,1);
u(bdNode)                               = g_D(node(bdNode,:));
A                                       = assembling(node,elem);



A_cell                                  = cell(J,1);
A_cell{J}                               = A;
A_new                                   = A;
A_tril                                  = cell(J,1);
A_triu                                  = cell(J,1);
A_tril{J}                               = tril(A_new);
A_triu{J}                               = triu(A_new);
A_pro                                   = cell(J,1);
A_res                                   = cell(J,1);

for i = J-1:-1:2
    pro                                 = prolongation_HB1(HB_cell{i+1});
    res                                 = pro';
    A_pro{i+1}                          = pro;
    A_res{i+1}                          = res;
    A_new                               = res*A_new*pro;
    A_cell{i}                           = A_new;
    A_tril{i}                           = tril(A_new);
    A_triu{i}                           = triu(A_new);
end
i =1;
pro                                     = prolongation_HB1(HB_cell{i+1});
res                                     = pro';
A_pro{2}                                = pro;
A_res{2}                                = res;
A_cell{1}                               = res*A_new*pro;

r_list = [];

e_list = [];
for i = 1:100
    r                                       = b - A*u;
%     exactu                                  = inline('0.*sin(pi*pxy(:,1)).*sin(pi*pxy(:,2))','pxy');
%     err                                     = getL2error(node,elem,exactu,r);
    r_list                                  = [r_list max(abs(r)) ];
    e                                       = Vcycle4(r,J,A_cell,A_tril,A_triu,A_pro,A_res,bdNode_cell,freeNode_cell);
    e_list                                  = [e_list max(abs(e))];
    u                                       = u+e;
end
subplot(2,1,1);
semilogy(r_list)
title("semilogy plot residul for 0  initial condition J = 4 L1 norm");
subplot(2,1,2);
semilogy(e_list)
title("semilogy plot error for 0  initial condition J = 4 L1 norm");


figure(7);
plot3(node(:,1),node(:,2),u);







figure(5);

time_list_three = [];
time_list_four = [];
time_list_five = [];
time_list_six = [];

for J = 3:6
    
    [node,elem] = circlemesh(0,0,1,0.25);
    HB_cell       = cell(J,1);
    bdNode_cell   = cell(J,1);
    freeNode_cell = cell(J,1);

    for i = 1:J
        [node,elem,~,HB] = uniformrefine(node,elem);
        HB_cell{i}       = double(HB);
        [bdNode,bdEdge,isBdNode,isBdElem]       = findboundary(elem);
        freeNode                                = find(~isBdNode);
        bdNode_cell{i}                          = bdNode;
        freeNode_cell{i}                        = freeNode;
    end
    %[node,elem,~,HB] = uniformrefine(node,elem);
    %[elem,HB,~] = uniformcoarsenred(elem);
    % Step 2
    % showmesh(node,elem);
    N                                       =  length(node);
    mid1                                    = (node(elem(:,2),:)+node(elem(:,3),:))/2;
    mid2                                    = (node(elem(:,3),:)+node(elem(:,1),:))/2;
    mid3                                    = (node(elem(:,1),:)+node(elem(:,2),:))/2;
    area0                                   = assembling_area(node,elem);
    bt1                                     = area0.*(f1(mid2)+f1(mid3))/6;
    bt2                                     = area0.*(f1(mid3)+f1(mid1))/6;
    bt3                                     = area0.*(f1(mid1)+f1(mid2))/6;
    b                                       = accumarray(elem(:),[bt1;bt2;bt3],[N 1]);

    [bdNode,bdEdge,isBdNode,isBdElem]       = findboundary(elem);
    freeNode                                = find(~isBdNode);
    u                                       = zeros(N,1);
    u                                       = rand(N,1);
    u(bdNode)                               = g_D(node(bdNode,:));
    A                                       = assembling(node,elem);

    A_cell                                  = cell(J,1);
    A_cell{J}                               = A;
    A_new                                   = A;
    A_tril                                  = cell(J,1);
    A_triu                                  = cell(J,1);
    A_tril{J}                               = tril(A_new);
    A_triu{J}                               = triu(A_new);
    A_pro                                   = cell(J,1);
    A_res                                   = cell(J,1);

    for i = J-1:-1:2
        pro                                 = prolongation_HB1(HB_cell{i+1});
        res                                 = pro';
        A_pro{i+1}                          = pro;
        A_res{i+1}                          = res;
        A_new                               = res*A_new*pro;
        A_cell{i}                           = A_new;
        A_tril{i}                           = tril(A_new);
        A_triu{i}                           = triu(A_new);
    end

    i =1;
    pro                                     = prolongation_HB1(HB_cell{i+1});
    res                                     = pro';
    A_pro{2}                                = pro;
    A_res{2}                                = res;
    A_cell{1}                               = res*A_new*pro;

    
    for i = 1:30
        tic;
        r                                       = b*(1/4*2^J) - A*u;
        r_list                                  = [r_list max(abs(r))];
        e                                       = Vcycle(r,J,A_cell,A_tril,A_triu,A_pro,A_res,bdNode_cell,freeNode_cell);
        u                                       = u+e;
        toc;
        t1                                      = toc;
        if J == 3 
            if i == 1
                time_list_three = [t1];
            else
                time_list_three = [time_list_three t1+time_list_three(end)];
            end
        elseif J == 4 
            if i == 1
                time_list_four = [t1];
            else
                time_list_four = [time_list_four t1+time_list_four(end)];
            end  
        elseif J == 5     
            if i == 1
                time_list_five = [t1];
            else
                time_list_five = [time_list_five t1+time_list_five(end)];
            end 
        else
            if i == 1
                time_list_six = [t1];
            else
                time_list_six = [time_list_six t1+time_list_six(end)];
            end 
        end
    end
    
end

plot(time_list_three)
hold on;
plot(time_list_four)
plot(time_list_five)
plot(time_list_six)
legend("three","four","five","six");
title("time vers J = 3,4,5,6")
