function [output] = Vcycle4(r,J,A_cell,A_tril,A_triu,A_pro,A_res,bdNode_cell,freeNode_cell) 

    ri    = cell(J,1);
    ei    = cell(J,1);
    ki    = cell(J,1);
    ri{J} = r;
    
    for i = J:-1:2
        ii          = freeNode_cell{i};
        jj          = bdNode_cell{i};
        ri{J}(jj)   = 0;  
        ei{i}       = zeros(length(ri{i}),1);
        ei{i}(ii)   = A_tril{J}(ii,ii)\ri{i}(ii);
        ki{J}       = (ri{i}-A_cell{i}*ei{i});
        ki{J}(jj)   = 0;
        ri{i-1}     = A_res{i}* ki{J};

    end
    ii          = freeNode_cell{1};
    ei{1}       = zeros(length(ri{1}),1);
    ei{1}(ii)   = A_cell{1}(ii,ii)\ri{1}(ii);
    
    for i = 2:J

       ii          = freeNode_cell{i};
       jj          = bdNode_cell{i};
       ei{i}       = ei{i} + A_pro{i}*ei{i-1};
       ei{i}(jj)   = 0;
       ki{i}       = (ri{i}-A_cell{i}*ei{i});
       ki{i}(jj)   = 0;
       ei{i}       = ei{i} + A_triu{i}\ki{i};
    end
    output = ei{J};
end