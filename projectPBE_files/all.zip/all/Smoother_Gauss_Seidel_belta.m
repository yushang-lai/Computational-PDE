function [output] = Smoother_Gauss_Seidel_belta(h,hx,u,ii) 

    n   =  hx/h-1;
    err = 10;
    tol = h^2;
    num   = 0;
    
    um   = Smoother_Gauss_Seidel1(h,hx,u,50000); 
    while err>tol
        for j=2:n+1
            for i=2:n+1
                u(i,j)= (h^2+(u(i-1,j)+u(i+1,j)+u(i,j-1)+u(i,j+1)))/4;
            end
        end
        err = abs(max(max((u(2:end-1,2:end-1)-um))));
        num = num+1;
    end
    output = num;
end