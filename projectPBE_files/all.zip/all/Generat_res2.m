function [output] = Generat_res2(f,u,A)
    f  = reshape(f,length(f)^.5,length(f)^.5);
    ff = zeros(length(f),length(f));
    h  = 1/(length(u)-1);
    f  = f_Dirch(h,1,1,u,f);
    u  = u(2:end-1,2:end-1);
    u  = u(:);
    r  = f - A*u;
    r  = reshape(r,length(r)^.5,length(r)^.5);
    ff(2:end-1,2:end-1) = r;
    output = ff(:);
end