function [output] = Vcycle2(u,J,A_cell,A_tril,A_triu) 

    n     = length(u)-1;
    h     = 1/n;
    for i = J:-1:1
        A1{i} = GeneratA_Dirch(h,1,1);
        h    = 2*h;
    end   
    
    ri    = cell(J,1);
    ei    = cell(J,1);
    ui    = cell(J,1);
    ui{J} = u;
    
    r     = (1/n)^2*ones(size(u));
    ri{J} = r;
    
    for i = J:-1:2
        ui{i}   = Smoother_F(ui{i},10);
        ei{i}   = get_E(A1{i},ri{i});
        ri{i-1} = restriction(Generat_res(ri{i},ui{i},A1{i}));
        ui{i-1} = restriction(ui{i});
    end 
    r2 = ri{1};
    r2 = r2(2:end-1,2:end-1);
    e1 = A1{1}\r2(:);
    e1 = reshape(e1,length(e1)^.5,length(e1)^.5);
    ei{1} = linetomatrix(e1);
    for i = 2:J
        ui{i} = ui{i} + prolongation(ei{i-1},1);
        ui{i} = Smoother_B(ui{i},10);
    end
    output = ui{J};
end