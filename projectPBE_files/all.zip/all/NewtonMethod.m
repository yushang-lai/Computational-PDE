function u = NewtonMethod(u,tol,A,freeNode)

%     u  = u0;
    n = length(u);
    h = 1/(sqrt(n)-1);
    r0 = -h^2*sinh(u) - A*u;
    r  = r0;
    err = 1;
    
    while err >= tol
       J = A + spdiags(cosh(u)*h^2,0,n,n);
       e = J(freeNode,freeNode)\r(freeNode);
%        e = amg(J(freeNode,freeNode),r(freeNode));
       u(freeNode) = u(freeNode) + e;
       r = -h^2*sinh(u) - A*u;
       err = norm(r(freeNode))/norm(r0);
       %disp(err);

    end
% end
%     