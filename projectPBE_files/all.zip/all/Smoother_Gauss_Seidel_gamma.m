function [err_lst rando] = Smoother_Gauss_Seidel_gamma(h,hx,u,ii) 
    n         =  hx/h-1;
    u(2:end-1,2:end-1) = 10*rand(n,n);
    rando  = u;
    n   =  hx/h-1;
    for k = 1:ii
        for j=2:n+1
            for i=2:n+1
                u(i,j)= (h^2+(u(i-1,j)+u(i+1,j)+u(i,j-1)+u(i,j+1)))/4;
            end
        end
        if k == 1 
            output1 = u(2:end-1,2:end-1);
        end
        if k == 2 
            output2 = u(2:end-1,2:end-1);
        end
        if k ==3 
            output3 = u(2:end-1,2:end-1);
        end
    end
    output = u(2:end-1,2:end-1);
    a= abs(max(max((output-output1))));
    b= abs(max(max((output-output2))));
    c= abs(max(max((output-output3))));
    err_lst = [a,b,c] ;
end