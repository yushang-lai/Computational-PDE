% Multigrid on Hierarchical Grids
% Step 1
[node,elem] = circlemesh(0,0,1,0.25);
J = 4;
HB_cell       = cell(J,1);
bdNode_cell   = cell(J,1);
freeNode_cell = cell(J,1);

for i = 1:J
    [node,elem,~,HB] = uniformrefine(node,elem);
    HB_cell{i}       = double(HB);
    [bdNode,~,isBdNode,~]                   = findboundary(elem);
    freeNode                                = find(~isBdNode);
    bdNode_cell{i}                          = bdNode;
    freeNode_cell{i}                        = freeNode;
end
%[node,elem,~,HB] = uniformrefine(node,elem);
%[elem,HB,~] = uniformcoarsenred(elem);
figure(4);
% Step 2
% showmesh(node,elem);
N                                       =  length(node);
mid1                                    = (node(elem(:,2),:)+node(elem(:,3),:))/2;
mid2                                    = (node(elem(:,3),:)+node(elem(:,1),:))/2;
mid3                                    = (node(elem(:,1),:)+node(elem(:,2),:))/2;
area0                                   = assembling_area(node,elem);
bt1                                     = area0.*(f1(mid2)+f1(mid3))/6;
bt2                                     = area0.*(f1(mid3)+f1(mid1))/6;
bt3                                     = area0.*(f1(mid1)+f1(mid2))/6;
b                                       = accumarray(elem(:),[bt1;bt2;bt3],[N 1]);

[bdNode,bdEdge,isBdNode,isBdElem]       = findboundary(elem);
freeNode                                = find(~isBdNode);
u                                       = zeros(N,1);
u(bdNode)                               = g_D(node(bdNode,:));
A                                       = assembling(node,elem);



A_cell                                  = cell(J,1);
A_cell{J}                               = A;
A_new                                   = A;
A_tril                                  = cell(J,1);
A_triu                                  = cell(J,1);
A_tril{J}                               = tril(A_new);
A_triu{J}                               = triu(A_new);
A_pro                                   = cell(J,1);
A_res                                   = cell(J,1);

for i = J-1:-1:2
    pro                                 = prolongation_HB1(HB_cell{i+1});
    res                                 = pro';
    A_pro{i+1}                          = pro;
    A_res{i+1}                          = res;
    A_new                               = res*A_new*pro;
    A_cell{i}                           = A_new;
    A_tril{i}                           = tril(A_new);
    A_triu{i}                           = triu(A_new);
end
i =1;
pro                                     = prolongation_HB1(HB_cell{i+1});
res                                     = pro';
A_pro{2}                                = pro;
A_res{2}                                = res;
A_cell{1}                               = res*A_new*pro;

r_list = [];

e_list = [];
for i = 1:100
    r                                       = (1/2^12)*b - A*u;
    r_list                                  = [r_list max(abs(r(freeNode))) ];
    e                                       = Vcycle4(r,J,A_cell,A_tril,A_triu,A_pro,A_res,bdNode_cell,freeNode_cell);
    e_list                                  = [e_list max(abs(e(freeNode)))];
    u                                       = u+e;
end
plot(r_list)
title("semilogy plot residul for 0  initial condition J = 4 L1 norm");



