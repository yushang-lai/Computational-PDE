function [err_lst] = Smoother_Gauss_Seidel_alpha(h,hx,u,ii) 

    n   =  hx/h-1;
    for k = 1:ii
        for j=2:n+1
            for i=2:n+1
                u(i,j)= (h^2+(u(i-1,j)+u(i+1,j)+u(i,j-1)+u(i,j+1)))/4;
            end
        end
        if k == 3 
            output1 = u(2:end-1,2:end-1);
        end
        if k == 6 
            output2 = u(2:end-1,2:end-1);
        end
        if k ==9 
            output3 = u(2:end-1,2:end-1);
        end
        if k == 12 
            output4 = u(2:end-1,2:end-1);
        end
        if k ==15 
            output5 = u(2:end-1,2:end-1);
        end
        if k == 18 
            output6 = u(2:end-1,2:end-1);
        end
        if k == 21 
            output7 = u(2:end-1,2:end-1);
        end
        if k == 24 
            output8 = u(2:end-1,2:end-1);
        end
        if k == 27 
            output9 = u(2:end-1,2:end-1);
        end
        if k == 30 
            output10 = u(2:end-1,2:end-1);
        end
        if k == 33 
            output11 = u(2:end-1,2:end-1);
        end
        if k == 36 
            output12 = u(2:end-1,2:end-1);
        end
        if k == 39 
            output13 = u(2:end-1,2:end-1);
        end
        if k == 42 
            output14 = u(2:end-1,2:end-1);
        end
        
        
    end
    output = u(2:end-1,2:end-1);
    a= abs(max(max((output-output1))));
    b= abs(max(max((output-output2))));
    c= abs(max(max((output-output3))));
    d= abs(max(max((output-output4))));
    e= abs(max(max((output-output5))));
    f= abs(max(max((output-output6))));
    g= abs(max(max((output-output7))));
    hh=abs(max(max((output-output8))));
    iii =abs(max(max((output-output9))));
    iiii =abs(max(max((output-output10))));
    iiiii =abs(max(max((output-output11))));
    iiiij =abs(max(max((output-output12))));
    iiiik =abs(max(max((output-output13))));
    iiiil =abs(max(max((output-output14))));
    err_lst = [a,b,c,d,e,f,g,hh,iii,iiii,iiiii,iiiij,iiiik,iiiil] ;
end