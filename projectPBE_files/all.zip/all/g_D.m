function output = g_D(x)
    output = 0.*sin(2.*pi.*x(:,1)).*cos(2.*pi.*x(:,2));
end