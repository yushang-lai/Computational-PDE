function [output] = Vcycle(r,J,A_cell,A_tril,A_triu,A_pro,A_res,bdNode_cell,freeNode_cell) 

    ri    = cell(J,1);
    ei    = cell(J,1);
    ki    = cell(J,1);
    ri{J} = r;
    
    for i = J:-1:2
        ii          = freeNode_cell{i};
        jj1         = bdNode_cell{i};
        jj          = bdNode_cell{i-1};
        ri{J}(jj1)  = 0;
        ei{i}       = zeros(length(ri{i}),1);
        ei{i}(ii)   = inv(A_tril{i}(ii,ii))*ri{i}(ii);
        ki{i}       = zeros(length(ri{i}),1);
        ki{i}(ii)   = (ri{i}(ii)-A_cell{i}(ii,ii)*ei{i}(ii));
        %ki{i}(jj1)  = 0;
        ri{i-1}     = A_res{i}*ki{i};
        %ri{i-1}     = A_res{i}*(ri{i}-A_cell{i}*ei{i});
        ri{i-1}(jj) = 0; 

    end
    ii          = freeNode_cell{1};
    ei{1}       = zeros(length(ri{1}),1);
%     ei{1}(ii)   = A_cell{1}(ii)\ri{1}(ii);
    ei{1}(ii)  = A_cell{1}(ii)\ri{1}(ii);
    
    for i = 2:J
       ii          = freeNode_cell{i};
       ii1         = freeNode_cell{i-1};
%      ei{i}       = A_pro{i}*ei{i-1};
%      ei{i}(ii)   = inv(A_triu{i}(ii,ii))*ei{i}(ii);
       ei{i}       = ei{i} + A_pro{i}*ei{i-1};
       ei{i}(~ii)  = 0;
       ei{i}(ii)   = ei{i}(ii) + inv(A_triu{i}(ii,ii))*(ri{i}(ii)-A_cell{i}(ii,ii)*ei{i}(ii));
       ei{i}(~ii)  = 0;
    end
    output = ei{J};
end