function output = two_gridh(h)

    [node,elem] = squaremesh([0,1,0,1],h);
    HB_cell     = cell(2,1);

    N     =  length(node);
    [bdNode,~,isBdNode,~] = findboundary(elem);
    freeNode = find(~isBdNode);
    u        = zeros(N,1);
    u(bdNode)= ub2(node(bdNode,:));
    A        = assembling(node,elem);

    b        = -A*u;
    u(freeNode)= A(freeNode,freeNode)\(b(freeNode));

    tol = h^2*10^(-6);
    u   = NewtonMethod(u,tol,A,freeNode);


    for i = 1:2
        [node,elem,~,HB] = uniformrefine(node,elem);
        HB_cell{i}                              = double(HB);
        [bdNode,~,~,~ ]      = findboundary(elem);
    end

    u = prolongation_HB1(HB_cell{1})*u;
    u = prolongation_HB1(HB_cell{2})*u;

    N        =  length(node);
    [bdNode,~,isBdNode,~] = findboundary(elem);
    freeNode = find(~isBdNode);
    u        = zeros(N,1);
    u(bdNode)= ub2(node(bdNode,:));
    A        = assembling(node,elem);
    b        = -A*u;
    u(freeNode)= A(freeNode,freeNode)\(b(freeNode));

    tol = 10^(-6)*h^4;
    u   = NewtonMethod(u,tol,A,freeNode);

    u_exact = ub2(node);
    output = max(abs(u-u_exact));
end


