function u = two_grid(u,f,J,mu)

    h = 1/(length(u)-1);
    u = Smoother_F(u,mu);
    A = GeneratA_Dirch(h,1,1);
    r = Generat_res(f,u,A);
    r = restriction(r);
    r = r(2:end-1,2:end-1);
    A1 = GeneratA_Dirch(2*h,1,1);
    er = A1\r(:);
    er = reshape(er,length(er)^.5,length(er)^.5);
    er = linetomatrix(er);
    er = prolongation(er,1);
    u = u+er;
    u = Smoother_B(u,mu);
    
end