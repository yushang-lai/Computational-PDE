function output = f1(z)
    x = z(:,1);
    y = z(:,2);
    output = 0.*x.*y;
    output = output +1;
end