function [output] =  Aa(u)        
    n        =  (length(u))^(.5);
    e        =   ones(n,1);
    T        =   spdiags([-e 2*e -e], -1:1 ,n,n);
    output   =   kron(speye(n),T)+kron(T,speye(n)); 
end