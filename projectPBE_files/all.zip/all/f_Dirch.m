function [output] = f_Dirch(h,hx,hy,u,f) 
    
    n   =  hx/h-1;
    
    f   =  f(2:end-1,2:end-1);
    f   =  f(:);

    f(1) = f(1)+u(1,2)+u(2,1);
    f(n) = f(n)+u(n+1,1)+u(n+2,2);
    f(n*(n-1)+1) = f(n*(n-1)+1)+u(1,n+1)+u(2,n+2);
    f(n*n) = f(n*n) + u(n+1,n+2)+u(n+2,n+1);

    for i = 2:n-1
        f(i) = f(i)+ u(i+1,1);
    end
    for i = n*(n-1)+2:n^2-1
        f(i) = f(i)+ u(i+1-n*(n-1),n+2);
    end
    for i=1:n-2
        f(i*n+1) = f(i*n+1) + u(1,i+2);
    end
    for i=1:n-2
        f((i+1)*n) = f((i+1)*n) + u(n+2,i+2);
    end
    output = f;
end