function [output] = restriction(u)
    N  = ((length(u)+1))/2;
    i = [1:N];
    j = [1:N];
    uf = zeros(N,N);
    uf = u(2*i-1,2*j-1);
    output = uf;
end