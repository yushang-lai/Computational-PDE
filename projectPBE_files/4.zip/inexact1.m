function e2 = inexact1(J,r,B,theta) 
    e1  = 0;
    r_in = r;
    while norm(r_in > theta* norm(r)
        e2 = e1 + B\r_in;
        r_in = r - J.*e2;
        e1 = e2;
    end
    e2 = e1;
end