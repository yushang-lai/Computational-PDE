% Multigrid
L  = 3;
h  = 1/2^L;
hx = 1;
ii = 50000;
w  = 0.5;
% Step 1 Weighted Jacobi & Gasuss-Seidel Smoother 

% Weighter Jacobi 

u     = zeros(hx/h+1,hx/h+1);
u_w_j = Smoother_Weighted_Jaco(h,hx,u,ii,w);
u_g_s = Smoother_Gauss_Seidel1(h,hx,u,ii); 

ii1   = 10;
ii2   = 11;
ii3   = 12;
ii4   = 13;

u_g_s_1 = Smoother_Gauss_Seidel1(h,hx,u,ii1); 
u_g_s_2 = Smoother_Gauss_Seidel1(h,hx,u,ii2); 
u_g_s_3 = Smoother_Gauss_Seidel1(h,hx,u,ii3); 
u_g_s_4 = Smoother_Gauss_Seidel1(h,hx,u,ii4); 

k1_k  = max(max((u_g_s_4-u_g_s_3)));
k_k1  = max(max((u_g_s_3-u_g_s_2)));
k1_k2 = max(max((u_g_s_2-u_g_s_1)));
disp('The convergence rate is:');
q     = log(abs(k1_k/k_k1))/log(abs(k_k1/k1_k2))


% Plot the error for h = 1/16
figure(1);
L  = 4;
h  = 1/2^L;
u     = zeros(hx/h+1,hx/h+1);
err_lst =  Smoother_Gauss_Seidel_alpha(h,hx,u,ii);
subplot(2,2,1);
plot([3:3:42],err_lst)
title('h=1/16 error plot')


% Get Step number for h=1/4
L  = 2;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
disp('The step required to get h^2 error h = 1/4 is:');
nstep1 =  Smoother_Gauss_Seidel_belta(h,hx,u,ii)


% Get Step number for h = 1/128
L  = 7;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
disp('The step required to get h^2 error h = 1/128 is:');
nstep2 =  Smoother_Gauss_Seidel_belta(h,hx,u,ii)

L  = 1;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
nstep3 =  Smoother_Gauss_Seidel_belta(h,hx,u,ii);

L  = 6;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
nstep4 =  Smoother_Gauss_Seidel_belta(h,hx,u,ii);

subplot(2,2,2);
plot([1 2 6 7],[nstep3 nstep1 nstep4 nstep2],"o");
xlabel('L')
ylabel('*# steps')
title('# of steps r.p.t L ')

% Choose a random initial guess and plot the error in the first three steps
L  = 4;
h  = 1/2^L;
u  = zeros(hx/h+1,hx/h+1);
[err_lst, rando] =  Smoother_Gauss_Seidel_gamma(h,hx,u,ii);
subplot(2,2,3);
plot([1 2 3],err_lst);
title('random start')

% Step 2 Two-Grid Method

figure(2);
subplot(2,1,1);
L  = 2;
h  = 1/2^L;
hx = 1;
u  = zeros(hx/h+1,hx/h+1);
u_g_s_1 = Smoother_Gauss_Seidel1(h,hx,u,10000);
J = 2;
mu = 10;
f  = h^2*ones((hx/h+1));
err_lst1 = [];
for i =1:10
    u = two_grid(u,f,J,mu);
    err_lst1 = [err_lst1 abs(max(max(u(2:end-1,2:end-1)-u_g_s_1)))];
end
plot(err_lst1);
title('h=1/4');

subplot(2,1,2);
L  = 7;
h  = 1/2^L;
hx = 1;
u  = zeros(hx/h+1,hx/h+1);
u_g_s_2 = Smoother_Gauss_Seidel1(h,hx,u,10000);
J = 2;
mu = 10;
f  = h^2*ones((hx/h+1));
err_lst2 = [];
for i =1:10
    u = two_grid(u,f,J,mu);
    err_lst2 = [err_lst2 abs(max(max(u(2:end-1,2:end-1)-u_g_s_2)))];
end

plot(err_lst2);
title('h=1/128');

% Step 3 Vcycle
L  = 7;
h  = 1/2^L;
mu = 10;
hx = 1;
u2  = zeros(hx/h+1,hx/h+1);
error =1;
tol = 0.1*h^2;
J = 4;
f  = h^2*ones((hx/h+1));
u_g_s_2 = Smoother_Gauss_Seidel1(h,hx,u2,10000);
kk =1;
error_lst = [];
while error > tol
    u2 = Vcycle1(u2,J);
    kk = kk+1;
    error = abs(max(max(u2(2:end-1,2:end-1)-u_g_s_2)));
    error_lst = [error_lst error];
end
plot(error_lst)

