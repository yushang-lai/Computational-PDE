function [output] = Smoother_B(u,ii)
    h   = 1/(length(u)+1);
    n   =  length(u)-2;
    for k = 1:ii
        j=[n+1:-1:2];
        i=[n+1:-1:2];
        u(i,j)= (h^2+(u(i-1,j)+u(i+1,j)+u(i,j-1)+u(i,j+1)))/4;
    end
    output = u;
end