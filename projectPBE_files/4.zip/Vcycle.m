function [output] = Vcycle(r,J) 
    n     = length(r)-1;
    h     = 1/n;
    for i = J:-1:1
        A1{i} = GeneratA_Dirch(h,1,1);
        h    = 2*h;
    end   
    
    ri    = cell(J,1);
    ei    = cell(J,1);
    ki    = cell(J,1);
    ri{J} = r;
    
    for i = J:-1:2
        %ri{i}   = Smoother_F(ri{i},10)
        ei{i}   = get_E(A1{i},ri{i});
        ri{i-1} = restriction(Generat_res(ri{i},ei{i},A1{i}));
    end
    r2 = ri{1};
    r2 = r2(2:end-1,2:end-1);
    e1 = A1{1}\r2(:);
    e1 = reshape(e1,length(e1)^.5,length(e1)^.5);
    ei{1} = linetomatrix(e1);
    for i = 2:J
        ei{i} = ei{i} + prolongation(ei{i-1},1);
        %ei{i} = ei{i} + Smoother_B(Generat_res(ri{i},ei{i},A1{i}),10);
        %ei{i} = Smoother_B(ei{i},10);
    end
    output = ei{J};
end