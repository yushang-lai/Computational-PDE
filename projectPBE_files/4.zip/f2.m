function output = f2(x,h)
    output = -sinh(ub(x)); % not in iuse
end