function output = g_N(pt)
    output = zeros(length(pt),1);
    pt1    = pt(:,1);
    pt2    = pt(:,2);
    output(pt2==0) =  output(pt(:,2)==0);
    output(pt2==1) = - 2*pi*sin(2*pi*pt1(pt2==1)).*sin(2*pi);
    output(pt1==0) =  -2*pi*cos(0)   .*cos(2*pi.*pt2(pt1==0));
    output(pt1==1) =  2*pi*cos(2*pi).*cos(2*pi.*pt2(pt1==1));
end