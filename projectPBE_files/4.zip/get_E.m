function e0 = get_E(A,r)
    r0 = r;
    r0 = r0(2:end-1,2:end-1);
    e0 = A\r0(:);
    e0 = reshape(e0,length(e0)^.5,length(e0)^.5);
    e0 = linetomatrix(e0);
end