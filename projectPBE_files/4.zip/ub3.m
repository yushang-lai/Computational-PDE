function output = ub3(x)
    a = x(:,1);
    b = x(:,2);
    % output = ubar(0.1+(a+2.*b)./(5)^0.5)  ;
    output = zeros(length(a),1);
end