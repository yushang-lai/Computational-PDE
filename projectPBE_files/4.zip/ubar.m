function [output] = ubar(s)
    output = log((1+cos(s))./(1-cos(s))); 
end