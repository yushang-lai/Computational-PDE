function [output] = prolongation(u,idex)

    N  = length(u);
    uf = zeros(2*N-1,2*N-1);
    i = [1:N];
    j = [1:N];
    uf(2*i-1,2*j-1) = u;
    uf(2*i(1:end-1) ,2*j-1)       = (u(1:end-1,1:end) + u(2:end,1:end))/2;
    uf(2*i-1,2*j(1:end-1))        = (u(1:end,1:end-1) + u(1:end,2:end))/2;
    if length(uf)> 1
%         uf(2*i(1:N-1),2*j(1:N-1)) = (u(1:2:end-1,1:2:end-1) + u(3:2:end,1:2:end-1))/4 + (u(1:2:end-1,3:2:end) + u(3:2:end,3:2:end))/4;
        uf(2*i(1:N-1),2*j(1:N-1)) = (uf(2*i(1:N-1)-1,2*j(1:N-1)+1)+uf(2*i(1:N-1)-1,2*j(1:N-1)-1)+uf(2*i(1:N-1)+1,2*j(1:N-1)-1) + +uf(2*i(1:N-1)+1,2*j(1:N-1)+1))/4;
        
    end
    if idex == 1
        output = uf;
    else
        output = reshape(uf,(2*N-1)^2,1);
    end
end