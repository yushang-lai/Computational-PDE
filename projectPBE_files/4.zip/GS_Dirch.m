function [err,um] = GS_Dirch(A2,h,hx,hy,n,u,f,err,tol) 

    n  = hx/h-1;
    um = zeros(n,n);
    u2 = u(2:end-1,2:end-1);
    um(1,:)= u2(1,:);
    um(end,:)=u2(end,:);
    um(:,1)=u2(:,1);
    um(:,end) = u2(:,end);
     while err > tol
         for j = 2:n-1
             for i = 2:n-1
                um(i,j)  = (f(i,j) + um(i-1,j) + um(i+1,j) + um(i,j-1) +um(i,j+1))/4;
             end
         end
         err = norm(f(:)-A2 *um(:))/norm(f(:));
         %disp(err);
     end
end