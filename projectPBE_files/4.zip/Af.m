function [output] =  Af(u)        
    n        =  (length(u));
    output   =  ones(n,1);
end