function u = MG2(u,f,J,mu)
    % Direct update form of Multigrid Method
    if J == 1 % coarsest level: exact solve
        u = reshape(u,(length(u))^(.5),(length(u))^(.5);
        u = u(2:end,2:end);
        u = Aa(u)\f;
    end
    % Presmoothing
    u = Smoother_Gauss_Seidel(u,mu);
    disp(length(u))
    % Restrictiondfsdx
    if J~=1
        rc = restriction(f-Aa(u)*u);
    end
    disp(length(u))
    % Coarse grid correction
    if J~=1
        ec = MG2(zeros(length(rc),1),rc,J-1,mu);
    end
    % Prolongation
    if J~=1
        u = u + prolongation(ec);
    end
    disp(length(u))
    % Postsmoothing
    u = Smoother_Gauss_Seidel_back(u,mu);
end