function output = update1(A,u_old,e)

    alpha = 1;
    r_old = norm(-sinh(u_old)-A*u_old);
    r     = r_old +1;
    u     = u_old;
    
    while r> r_old
        u     = u_old + alpha * e;
        r     = norm(-sinh(u)-A*u);
        alpha = alpha / 2; 
    end
    
    output = u;
end