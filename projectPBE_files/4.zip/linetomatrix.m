function [output] = linetomatrix(u)
    n = length(u);
    u1 = zeros(n+2);
    u1(2:end-1,2:end-1) = u;
    output = u1;
end