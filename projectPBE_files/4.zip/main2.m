% Step 1 LPBE
% We solve ....
h = 1/128;
[node,elem] = squaremesh([0,1,0,1],h);
[node,elem] = uniformrefine(node,elem);
[node,elem] = uniformrefine(node,elem);
%showmesh(node,elem);
N     =  length(node);
[bdNode,bdEdge,isBdNode,isBdElem] = findboundary(elem);
freeNode = find(~isBdNode);
u        = zeros(N,1);
u(bdNode)= ub2(node(bdNode,:));
A        = assembling(node,elem);
ii       = 1:N;
b        = -A*u;
u(freeNode)= A(freeNode,freeNode)\(b(freeNode));
% u(freeNode)                 = amg(A,b(freeNode));
u_exact = ub2(node);
display(max(abs(u-u_exact)));
subplot(1,2,1);
showsolution(node,elem,u);
subplot(1,2,2);
showsolution(node,elem,u_exact);

% Step 2 Newton's Method.

tol = h^2*10^(-7);
u   = NewtonMethod(u,tol,A,freeNode);
display(max(abs(u-u_exact)));

% trimesh(elem, node(:,1),node(:,2),ub2(node)-u)
% trimesh(elem, node(:,1),node(:,2),u);



error = two_gridh(1/4)
error2 =  two_gridh(1/16)
