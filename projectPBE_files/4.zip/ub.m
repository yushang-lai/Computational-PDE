function output = ub(x)
    a = x(:,1);
    b = x(:,2);
    output =  ub2(x) ;
end
    