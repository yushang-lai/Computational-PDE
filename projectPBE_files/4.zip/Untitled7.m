    [node,elem] = squaremesh([0,1,0,1],0.25);
    for k = 1:4
        exactu = inline('sin(pi*pxy(:,1)).*sin(pi*pxy(:,2))','pxy');
        Du = inline('[pi*cos(pi*pxy(:,1)).*sin(pi*pxy(:,2)) pi*sin(pi*pxy(:,1)).*cos(pi*pxy(:,2))]','pxy');
        uI = exactu(node);
        N(k) = size(node,1);
        err(k) = getH1error(node,elem,Du,uI);
        [node,elem] = uniformrefine(node,elem);
    end
    showrate(N,err);