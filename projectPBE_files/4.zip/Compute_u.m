function [u_d u_n] = Compute_u(node,elem)
    N     =  length(node);

    mid1  = (node(elem(:,2),:)+node(elem(:,3),:))/2;
    mid2  = (node(elem(:,3),:)+node(elem(:,1),:))/2;
    mid3  = (node(elem(:,1),:)+node(elem(:,2),:))/2;
    area0 = assembling_area(node,elem);
    bt1   = area0.*(f(mid2)+f(mid3))/6;
    bt2   = area0.*(f(mid3)+f(mid1))/6;
    bt3   = area0.*(f(mid1)+f(mid2))/6;
    b     = accumarray(elem(:),[bt1;bt2;bt3],[N 1]);


    %% Step 5

    % Dirchlet
    % bdFlag1                               = setboundary(node,elem,'Dirichlet');
    [bdNode,bdEdge,isBdNode,isBdElem] = findboundary(elem);
    % Dirchlet                              = bdEdge1;
    % isBdNode = false(N,1);
    % isBdNode(Dirichlet) = true;
    % bdNode = find(isBdNode);
    freeNode = find(~isBdNode);
    u = zeros(N,1);
    u(bdNode) = g_D(node(bdNode,:));
    A                                     = assembling(node,elem);
    b1 = b - A*u;
    u(freeNode) = A(freeNode,freeNode)\b1(freeNode);
    size(u(freeNode));
    size(A(2:end-1,2:end-1));
    size(b1(freeNode));
    u_d = u;
    % u(bdNode1)                            = g_D(node(bdNode1,:));
    % b1                                    = b;
    % A                                     = assembling(node,elem);
    % b1                                    = b1-A*u;

    % Neumann
    bdFlag2                               = setboundary(node,elem,'Neumann');
    [bdNode2,bdEdge2,isBdNode2,isBdElem2] = findboundary(elem,bdFlag2);
    Neumann                               = bdEdge2;
    b2                                    = b;

    if (~isempty(Neumann))
        Nve        = node(Neumann(:,1),:) - node(Neumann(:,2),:);
        edgeLength = sqrt(sum(Nve.^2,2));
        mid        = (node(Neumann(:,1),:) + node(Neumann(:,2),:))/2;
        b2         = b2 + accumarray([Neumann(:),ones(2*size(Neumann,1),1)],repmat(edgeLength.*g_N(mid)/2,2,1),[N,1]);
    end
    u_n    = zeros(length(node),1);
    u_n(1) = g_D(node(1,:));
    u_n(2:end) = A(2:end,2:end)\b2(2:end);
    u_n(2:end) = u_n(2:end) + g_D(node(2,:))-u_n(2);
end