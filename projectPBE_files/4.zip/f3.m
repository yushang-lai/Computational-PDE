function output = f3(x,h)
    output = -cosh(ub(x));
end