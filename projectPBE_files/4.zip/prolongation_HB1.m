function S = prolongation_HB1(HB)
    [n m] = size(HB);
    HB1 = double(HB(:,1));
    coarseNodeFineIdx = [1:double(HB1-1)]';
    coarseNode        = coarseNodeFineIdx;
    nCoarseNode       = length(coarseNode);
    nFineNode         =  length(HB1);
    ii = [coarseNodeFineIdx; HB(:,1); HB(:,1)];
    jj = [coarseNode; HB(:,2); HB(:,3)];
    ss = [ones(nCoarseNode,1); 0.5*ones(nFineNode,1); 0.5*ones(nFineNode,1)];
    S  = sparse(double(ii),double(jj),double(ss),nFineNode+nCoarseNode,nCoarseNode);

end