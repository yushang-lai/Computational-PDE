function [output] = Smoother_Weighted_Jaco(h,hx,u,ii,w) 
    n    =  hx/h-1;
    for k = 1:ii
        j=2:n+1;
        i=2:n+1;
        um(i,j)= (h^2+u(i-1,j)+u(i+1,j)+u(i,j-1)+u(i,j+1))/4;
        um     = um(2:end,2:end);
        u(2:end-1,2:end-1)  = w*u(2:end-1,2:end-1) + (1-w)*um;
    end
    output = u(2:end-1,2:end-1);
end