function [output] = Smoother_F1(u,ii)
    h   = 1/(length(u)+1);
    n   =  length(u)-2;

    for k = 1:ii
        for j=2:n+1
            for i=2:n+1
                u(i,j)= (h^2+(u(i-1,j)+u(i+1,j)+u(i,j-1)+u(i,j+1)))/4;
            end
        end
    end
    output = u;
end