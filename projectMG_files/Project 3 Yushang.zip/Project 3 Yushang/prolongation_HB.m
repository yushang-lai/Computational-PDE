function S = prolongation_HB(HB)
    [n m] = size(HB);
    ii = [1:2*n];
    S  =  sparse(double([ii HB(:,1)' HB(:,1)']),double([ii HB(:,2)' HB(:,3)']),[ones(1,2*n) 1/2*ones(1,n) 1/2*ones(1,n)],3*n,2*n);
    %u  = S*u;
end