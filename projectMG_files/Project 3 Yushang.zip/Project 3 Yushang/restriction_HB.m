function A = restriction_HB(HB)
    [n m] = size(HB);
    % u = u(1:2*n);
    ii = [1:2*n];
    A = (sparse([ii],[ii],[ones(1,2*n)],2*n,3*n));
end