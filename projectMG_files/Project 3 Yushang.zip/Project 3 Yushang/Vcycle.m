function [output] = Vcycle(r,J,A_cell,A_tril,A_triu,A_pro,A_res,bdNode_cell,freeNode_cell) 

    ri    = cell(J,1);
    ei    = cell(J,1);
    ki    = cell(J,1);
    ri{J} = r;
    
    for i = J:-1:2
        ii          = freeNode_cell{i};
        ei{i}       = zeros(length(ri{i}),1);
        ei{i}(ii)   = inv(A_tril{J}(ii,ii))*ri{i}(ii);
        ri{i-1}     = A_res{i}* (ri{i}-A_cell{i}*ei{i});

    end
    ii          = freeNode_cell{1};
    ei{1}       = zeros(length(ri{1}),1);
    ei{1}(11)   = A_cell{1}(ii)\ri{1}(ii);
    
    for i = 2:J
%        ei{i} = A_pro{i}*ei{i-1};
%        ei{i} = inv(A_triu{i})*ei{i};
       ei{i} = ei{i} + A_pro{i}*ei{i-1};
       ei{i} = ei{i} + inv(A_triu{i})*(ri{i}-A_cell{i}*ei{i});
    end
    output = ei{J};
end