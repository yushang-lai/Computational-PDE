function A = assembling_area(node,elem)
    N = size(node,1); NT = size(elem,1);
    ii = zeros(9*NT,1); jj = zeros(9*NT,1); sA = zeros(9*NT,1);
    ve(:,:,3) = node(elem(:,2),:)-node(elem(:,1),:);
    ve(:,:,1) = node(elem(:,3),:)-node(elem(:,2),:);
    ve(:,:,2) = node(elem(:,1),:)-node(elem(:,3),:);
    A = 0.5*abs(-ve(:,1,3).*ve(:,2,2)+ve(:,2,3).*ve(:,1,2));

end
    