%% Set path to iFEM  
%
% Add all subdirectories under pathstr to search path.
%
% Copyright (C) Long Chen. See COPYRIGHT.txt for details. 

addpath(genpath(pwd),'-begin');
savepath;

%% Step3 

t_lst       = [];
N_lst       = [];
[node,elem] = circlemesh(0,0,1,0.2);
N_lst       = [N_lst length(node)];

for j = 1:6
    
    fprintf('When the number of node N is: %10.1f\n',length(node));
    if j <=5
        tic; assemblingstandard(node,elem);  toc; t0 = toc;
        tic; assemblingsparse(node,elem);    toc; t1 = toc;
        tic; assembling(node,elem);          toc; t2 = toc;
        t_lst = [t_lst ; t0 t1 t2];
    else
        tic; assemblingsparse(node,elem);    toc; t1 = toc;
        tic; assembling(node,elem);          toc; t2 = toc;
        t_lst = [t_lst ; 0 t1 t2];
    end
    
    if j<6
        [node,elem] = uniformrefine(node,elem);
        j           = j+1;
        N_lst       = [N_lst length(node)];
    end
    
end

figure(1);
subplot(2,1,1);
semilogx(N_lst(1:end-1),t_lst(1:end-1,1),'r*-');
hold on;
semilogx(N_lst,t_lst(:,2),'bo-');
semilogx(N_lst,t_lst(:,3),'kx-');
legend('assemblingstandard','assemblingsparse','assembling')
title('semilogx plot')
subplot(2,1,2);
plot(N_lst(1:end-1),t_lst(1:end-1,1),'r*-');
%xticklabels({'N=1384', 'N=5407', 'N=21393', 'N=33749', 'N=41569', 'N=85093'})
hold on;
plot(N_lst,t_lst(:,2),'bo-');
plot(N_lst,t_lst(:,3),'kx-');
legend('assemblingstandard','assemblingsparse','assembling')
title('normal plot')


%% Step 4

[node,elem] = squaremesh([0,1,0,1],0.2);
[node,elem] = uniformrefine(node,elem);
[node,elem] = uniformrefine(node,elem);
[node,elem] = uniformrefine(node,elem);
[node,elem] = uniformrefine(node,elem);
[node,elem] = uniformrefine(node,elem);
[node,elem] = uniformrefine(node,elem);
[node,elem] = uniformrefine(node,elem);
showmesh(node,elem);

N     =  length(node);

mid1  = (node(elem(:,2),:)+node(elem(:,3),:))/2;
mid2  = (node(elem(:,3),:)+node(elem(:,1),:))/2;
mid3  = (node(elem(:,1),:)+node(elem(:,2),:))/2;
area0 = assembling_area(node,elem);
bt1   = area0.*(f(mid2)+f(mid3))/6;
bt2   = area0.*(f(mid3)+f(mid1))/6;
bt3   = area0.*(f(mid1)+f(mid2))/6;
b     = accumarray(elem(:),[bt1;bt2;bt3],[N 1]);


%% Step 5

[bdNode,bdEdge,isBdNode,isBdElem]       = findboundary(elem);
freeNode                                = find(~isBdNode);
u                                       = zeros(N,1);
u(bdNode)                               = g_D(node(bdNode,:));
A                                       = assembling(node,elem);
b1                                      = b - A*u;
u(freeNode)                             = A(freeNode,freeNode)\b1(freeNode);

% Neumann
bdFlag2                               = setboundary(node,elem,'Neumann');
[bdNode2,bdEdge2,isBdNode2,isBdElem2] = findboundary(elem,bdFlag2);
Neumann                               = bdEdge2;
b2                                    = b;

if (~isempty(Neumann))
    Nve        = node(Neumann(:,1),:) - node(Neumann(:,2),:);
    edgeLength = sqrt(sum(Nve.^2,2));
    mid        = (node(Neumann(:,1),:) + node(Neumann(:,2),:))/2;
    b2         = b2 + accumarray([Neumann(:),ones(2*size(Neumann,1),1)],repmat(edgeLength.*g_N(mid)/2,2,1),[N,1]);
end

    u_n    = zeros(length(node),1);
    u_n(1) = g_D(node(1,:));
    u_n(2:end) = A(2:end,2:end)\b2(2:end);
    u_n(2:end) = u_n(2:end) + g_D(node(2,:))-u_n(2);

%% Step 6
u1 = g_D(node);
figure(2);
showresult(node,elem,u1,[-62,58]);
figure(3);
showresult(node,elem,u,[-62,58]);
figure(4);
showresult(node,elem,u_n,[-62,58]);


%% Step 6.2

[node,elem] = squaremesh([0,1,0,1],0.2);
[node,elem] = uniformrefine(node,elem);
H1_lst_n    = [];
L2_lst_n    = [];
H1_lst_d    = [];
L2_lst_d    = [];
st_lst_n    = [];
st_lst_d    = [];
st_lst_n2   = [];
st_lst_d2   = [];

for k = 1:5
    [node,elem]   = uniformrefine(node,elem);
    [ud un]       = Compute_u(node,elem);
    exactu1       = inline('sin(2*pi*pxy(:,1)).*cos(2*pi*pxy(:,2))','pxy');
    exactu2       = inline('[2*pi*cos(2*pi.*pxy(:,1)).*cos(2*pi.*pxy(:,2)) -2*pi*sin(2*pi.*pxy(:,1)).*sin(2*pi.*pxy(:,2))]','pxy');
    uI            = exactu1(node);
    ui            = g_D(node);
    A             = assembling(node,elem);
    N(k)          = size(node,1);
    L2_lst_n(k)   = getL2error(node,elem,exactu1,un);
    H1_lst_n(k)   = getH1error(node,elem,exactu2,uI);
    L2_lst_d(k)   = getL2error(node,elem,exactu1,ud);
    H1_lst_d(k)   = getH1error(node,elem,exactu2,uI);
    st_lst_n(k)   = sqrt((ui-un)'*A*(ui-un));
    st_lst_d(k)   = sqrt((ui-ud)'*A*(ui-ud));
    st_lst_n2(k)  = sqrt(sum((ui-un).^2));
    st_lst_d2(k)  = sqrt(sum((ui-ud).^2));
end

figure(5);
subplot(2,2,1);
showrate(N,L2_lst_n);
xlabel('L2 Norm Neumann');
subplot(2,2,2);
showrate(N,H1_lst_n);
xlabel('H1 Norm Nuemann');
subplot(2,2,3);
showrate(N,L2_lst_d);
xlabel('L2 Norm Dirchlet');
subplot(2,2,4);
showrate(N,H1_lst_d);
xlabel('H1 Norm Dirchlet');

figure(6);
subplot(1,2,1);
showrate(N,st_lst_n);
xlabel('||Grident(Ui-Uh)|| Neumann');
subplot(1,2,2);
showrate(N,st_lst_d);
xlabel('||Grident(Ui-Ud)|| Dirchlet');



