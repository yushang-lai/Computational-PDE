function output = g_D(x)
    output = sin(2.*pi.*x(:,1)).*cos(2.*pi.*x(:,2));
end