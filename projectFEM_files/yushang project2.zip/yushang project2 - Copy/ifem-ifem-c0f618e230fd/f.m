function output = f(k)
    x = k(:,1);
    y = k(:,2);
    output = 8*pi*pi*sin(2.*pi.*x).*cos(2.*pi.*y);
end